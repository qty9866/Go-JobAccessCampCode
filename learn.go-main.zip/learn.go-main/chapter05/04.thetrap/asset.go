package main

type Asset interface{}

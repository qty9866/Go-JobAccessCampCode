package main

func main() {
	legendary(&manLegend{}, Refrigerator{}, Elephant{})
}

package main

type Config struct {
	Content string
}

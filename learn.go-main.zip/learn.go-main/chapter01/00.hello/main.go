package main

import (
	"fmt"
)

func main() {
	fmt.Println("1. 打开   冰箱")
	fmt.Println("2. 把大象装进去")
	fmt.Println("3. 关上   冰箱")
	fmt.Println("finished")
}

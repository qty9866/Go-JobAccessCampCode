package main

import (
	"fmt"
)

func main() {
	fmt.Println("中文，abc，1234，🧡")
	fmt.Printf("我的名字是%s\n", "小强")
	fmt.Printf("我的名字是%q\n", "小强")
	fmt.Printf("我的名字是%x\n", "小强")
	fmt.Printf("我的名字是%X\n", "小强")
}
